package org.spaceappschallenge.y2025.pear_up_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PearUpApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
