package org.spaceappschallenge.y2025.pear_up_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PearUpApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(PearUpApiApplication.class, args);
	}

}
